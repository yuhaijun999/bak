<figure align="center">
  <img src="../../images/docs/rebase.gif" alt="Interactive rebase editor"/>
  <figcaption>Interactive rebase editor</figcaption>
</figure>
