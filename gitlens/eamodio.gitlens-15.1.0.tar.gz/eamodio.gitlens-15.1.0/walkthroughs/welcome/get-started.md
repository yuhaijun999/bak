<figure align="center">
  <a href="https://www.youtube.com/watch?v=UQPb73Zz9qk?utm_source=gitlens-extension&amp;utm_medium=walkthru_welcome" title="Watch the Getting Started tutorial video">
    <img src="tutorial.png" alt="GitLens tutorial video" />
  </a>
</figure>

<figure align="center">
  <p><strong>GitLens Overview</strong></p>
  <a href="command:gitlens.showWelcomePage" title="Open GitLens Welcome">
    <img src="../../images/docs/side-bar-views.png" alt="GitLens Side Bar & Panel overview" />
  </a>
  <figcaption>GitLens Inspect as shown above has been manually dragged into the Secondary Side Bar</figcaption>
</figure>
