<figure align="center">
  <img src="power-up.png" alt="Power-up with Pro and the GitKraken DevEx Platform" />
</figure>
